package me.alessio2010.pokehubquests.configuration.quests;

public class TypesOfQuest {

    public static String BREAK_BLOCK = "BREAK_BLOCK";
    public static String PLACE_BLOCK = "PLACE_BLOCK";



    public String getBreakBlock() {
        return BREAK_BLOCK;
    }
    public String getPlaceBlock() {
        return PLACE_BLOCK;
    }

}
