package me.alessio2010.pokehubquests.utils;

public class Utils {
}
